yy = [];
for k =-5:5
    yy(k+6) = cos(k*pi/3);
end
yy