z = 3 + 4i;
w = -3 + 4j;
real(z)
imag(z)
abs(w)
conj(w)
angle(z)
exp(1i*pi)
exp(1i*[pi/4, 0, -pi/4])